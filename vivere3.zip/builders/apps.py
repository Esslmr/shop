from django.apps import AppConfig


class BuildersConfig(AppConfig):
    name = 'builders'
